import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class DoctorPatientHistory extends HBox
{
	public Button logout;
	
	@SuppressWarnings("unchecked")
	public DoctorPatientHistory(ArrayList<Patient> pList)
	{
		HBox hbox = new HBox();
		HBox buttonBox = new HBox();
		VBox vbox = new VBox();
		@SuppressWarnings("rawtypes")
		TableView patientTable = new TableView();
		
		@SuppressWarnings("rawtypes")
		TableColumn pFirst = new TableColumn("First Name");
		pFirst.setCellValueFactory(new PropertyValueFactory<>("firstName"));
		pFirst.setMinWidth(200);
		
		@SuppressWarnings("rawtypes")
		TableColumn pLast = new TableColumn("Last Name");
		pLast.setCellValueFactory(new PropertyValueFactory<>("lastName"));
		pLast.setMinWidth(200);
		
		@SuppressWarnings("rawtypes")
		TableColumn bTemp = new TableColumn("Body Temp");
		bTemp.setCellValueFactory(new PropertyValueFactory<>("bloodP"));
		bTemp.setMinWidth(100);
		
		@SuppressWarnings("rawtypes")
		TableColumn bPressure = new TableColumn("Blood Pressure");
		bPressure.setCellValueFactory(new PropertyValueFactory<>("temp"));
		bPressure.setMinWidth(100);

		patientTable.getColumns().addAll(pFirst, pLast, bTemp, bPressure);
		
		pList = new ArrayList<Patient>();
		try 
		{
			FileReader fr = new FileReader("Patients.txt");
			BufferedReader br = new BufferedReader(fr);
			
			String line = br.readLine();
			while(line != null)
			{
				String[] patientInfo = line.split(",");
				Patient newPatient = new Patient();
				newPatient.readFromFilePatient(patientInfo);
				pList.add(newPatient);
				line = br.readLine();
			}
			br.close();
		} 
		catch (IOException e) 
		{
			PopupMessages.error("Error", "Please make an account or program is missing the Patients.txt file");
		}
		
		for(Patient patient : pList)
		{
			patientTable.getItems().add(new Patient(patient.getFirstName(), patient.getLastName(), patient.getTemp(), patient.getBloodP()));
		}
		
		logout = new Button("Log Out");
		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_CENTER);
		buttonBox.getChildren().addAll(logout);
		
		vbox.setSpacing(10);
		vbox.setPadding(new Insets(10, 10, 10, 10));
		vbox.getChildren().addAll(buttonBox);
		
		hbox.getChildren().addAll(patientTable, vbox);
		this.getChildren().add(hbox);

		logout.setOnAction(event -> 
		{
			MainLogin login = new MainLogin();
			StackPane loginPane = new StackPane();
			loginPane.getChildren().add(login);
			Scene loginScene = new Scene(loginPane, 300, 400);
			ProjectMain.getStage().setScene(loginScene);
		});
	}
}

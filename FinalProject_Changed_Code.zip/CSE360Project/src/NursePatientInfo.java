import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.control.CheckBox;

public class NursePatientInfo extends HBox
{
	public Label patientName;
	public Label patientTemp;
	public Label patientWeight;
	public Label patientHeight;
	public Label patientBloodP;
	public TextField patientNameField;
	public TextField patientTempField;
	public TextField patientWeightField;
	public TextField patientHeightField;
	public TextField patientBloodPField;
	public Text patientInfo;
	public Text currentUser;
	public Button nextButton;
	public CheckBox overTwelveBox;
	
	public NursePatientInfo(ArrayList<Patient> pList, Staff user)
	{
		HBox buttonBox = new HBox();
		
		patientName = new Label("Patient Name");
		patientWeight = new Label("Patient Weight");
		patientTemp = new Label("Patient Temperature");
		patientHeight = new Label("Patient Height");
		patientBloodP = new Label("Patient Blood Pressure");
		
		patientInfo = new Text("    Please Fill Out\nPatient Information");
		patientInfo.setFont(Font.font(26));

		
		nextButton = new Button("Next");
		patientNameField = new TextField();
		patientWeightField = new TextField();
		patientTempField = new TextField();
		patientHeightField = new TextField();
		overTwelveBox = new CheckBox("Patient is over 12 years old?");

		patientBloodPField = new TextField();
		patientBloodPField.disableProperty().bind(overTwelveBox.selectedProperty().not());
		
		GridPane oPane = new GridPane();
		oPane.setAlignment(Pos.CENTER);
		GridPane mPane = new GridPane();
		mPane.setAlignment(Pos.CENTER);
		mPane.setPadding(new Insets(10, 10, 10, 10));
		
		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_CENTER);
		buttonBox.getChildren().add(nextButton);
		
		mPane.setMinSize(600, 300);
		mPane.add(patientName, 1, 0);
		GridPane.setHalignment(patientName, HPos.CENTER);
		mPane.add(patientNameField, 1, 1);
		
		mPane.add(patientWeight, 1, 2);
		GridPane.setHalignment(patientWeight, HPos.CENTER);
		mPane.add(patientWeightField, 1, 3);
		
		mPane.add(patientTemp, 1, 4);
		GridPane.setHalignment(patientTemp, HPos.CENTER);
		mPane.add(patientTempField, 1, 5);
		
		mPane.add(patientHeight, 1, 6);
		GridPane.setHalignment(patientHeight, HPos.CENTER);
		mPane.add(patientHeightField, 1, 7);
		
		mPane.add(overTwelveBox, 1, 8);
		
		mPane.add(patientBloodP, 1, 9);
		GridPane.setHalignment(patientBloodP, HPos.CENTER);
		mPane.add(patientBloodPField, 1, 10);
		

		mPane.add(buttonBox, 1, 11);
		mPane.setHgap(10);
		mPane.setVgap(10);
		
		BorderPane bPane = new BorderPane();
		BorderPane.setAlignment(mPane, Pos.CENTER);
		bPane.setCenter(mPane);
		bPane.setPadding(new Insets(5, 5, 5, 5));
		BorderPane.setAlignment(patientInfo, Pos.TOP_CENTER);
		bPane.setTop(patientInfo);

		oPane.add(bPane, 0, 0);
		oPane.setHgap(12);
		oPane.setVgap(12);

		this.getChildren().add(oPane);

		nextButton.setOnAction(event -> 
		{
			if(patientNameField.getText().isEmpty())
			{
				PopupMessages.error("Error", "Please enter a patient name");
			}
			else
			{
				try
				{
					FileWriter writer = new FileWriter("Patients.txt", false);

					for(Patient p : pList)
					{
						if(p.getPatientName().equals(patientNameField.getText()))
						{
							p.setWeight(patientWeightField.getText());
							p.setHeight(patientHeightField.getText());
							p.setTemp(patientTempField.getText());
							p.setBloodP(patientBloodPField.getText());
							writer.write(p.saveLine());
						}
						
						else
						{
							writer.write(p.saveLine());
						}
					}
					writer.close();
				}
				
				catch(IOException except)
				{
					PopupMessages.error("Error", "Missing Patients.txt file");
				}
				
				NursePatientHistory nursePatientHistory = new NursePatientHistory(pList, user);
				StackPane nurseHistoryPane = new StackPane();
				nurseHistoryPane.getChildren().add(nursePatientHistory);
				Scene nurseHistoryScene = new Scene(nurseHistoryPane, 600, 300);
				ProjectMain.getStage().setScene(nurseHistoryScene);
				ProjectMain.getStage().setTitle("Patient Information");
			}
		});
	}
}












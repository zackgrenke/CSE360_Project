import java.util.ArrayList;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;


public class StaffLogin extends HBox
{
	public Label userLabel;
	public Label passwordLabel;
	public TextField userField;
	public TextField passwordField;
	public Text staffLogin;
	public Button backButton;
	public Button loginButton;
	
	
	
	public StaffLogin(ArrayList<Patient> pList, ArrayList<Staff> sList)
	{		
		HBox buttonBox = new HBox();
		userLabel = new Label("Staff Username");
		passwordLabel = new Label("Staff Password");
		staffLogin = new Text("Staff Login");
		staffLogin.setFont(Font.font(36));
		backButton = new Button("Back");
		loginButton = new Button("Login");
		userField = new TextField();
		passwordField = new TextField();
		
		GridPane oPane = new GridPane();
		oPane.setAlignment(Pos.CENTER);
		GridPane mPane = new GridPane();
		mPane.setAlignment(Pos.CENTER);
		mPane.setPadding(new Insets(10, 10, 10, 10));

		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_CENTER);
		buttonBox.getChildren().add(backButton);
		buttonBox.getChildren().add(loginButton);
		

		mPane.setMinSize(600, 300);
		mPane.add(userLabel, 0, 0);
		GridPane.setHalignment(userLabel, HPos.CENTER);
		mPane.add(userField, 0, 1);
		
		mPane.add(passwordLabel, 0, 2);
		GridPane.setHalignment(passwordLabel, HPos.CENTER);
		mPane.add(passwordField, 0, 3);

		mPane.add(buttonBox, 0, 4);
		mPane.setHgap(10);
		mPane.setVgap(15);
		
		BorderPane bPane = new BorderPane();
		BorderPane.setAlignment(mPane, Pos.CENTER);
		bPane.setCenter(mPane);
		bPane.setPadding(new Insets(5, 5, 5, 5));
		BorderPane.setAlignment(staffLogin, Pos.CENTER);
		bPane.setTop(staffLogin);
		
		oPane.add(bPane, 0, 0);
		oPane.setHgap(12);
		oPane.setVgap(12);
		
		this.getChildren().add(oPane);
		
		backButton.setOnAction(event -> 
		{
			MainLogin login = new MainLogin();
			StackPane loginPane = new StackPane();
			loginPane.getChildren().add(login);
			Scene loginScene = new Scene(loginPane, 300, 400);
			ProjectMain.getStage().setScene(loginScene);
		});
		
		loginButton.setOnAction(event -> 
		{
			Staff currentUser = new Staff();
			String staffUser = userField.getText();
			String staffPass = passwordField.getText();
			Boolean userExist = false;
			Boolean isStaff = false;

			for(Staff s : sList)
			{
				if(s.getUser().equals(staffUser) && s.getPassword().equals(staffPass) && s.getisDoctor() == true)
				{
					userExist = true;
					isStaff = true;
					currentUser = s;
					break;
				}
				
				else if(s.getUser().equals(staffUser) && s.getPassword().equals(staffPass) && s.getisDoctor() == false)
				{
					userExist = true;
					isStaff = false;
					currentUser = s;
					break;
				}
				
				else
				{
					userExist = false;
				}
			}

			if(userExist == true && isStaff == false)
			{
				NursePatientInfo nursePatInfo = new NursePatientInfo(pList, currentUser);
				StackPane nursePatInfoPane = new StackPane();
				nursePatInfoPane.getChildren().add(nursePatInfo);
				Scene nursePatInfoScene = new Scene(nursePatInfoPane, 300, 600);
				ProjectMain.getStage().setScene(nursePatInfoScene);
				ProjectMain.getStage().setTitle("Patient Information");
			}

			else if(userExist == true && isStaff == true)
			{
				DoctorPatientHistory docPatHist = new DoctorPatientHistory(pList);
				StackPane docPatHistPane = new StackPane();
				docPatHistPane.getChildren().add(docPatHist);
				Scene docPatHistScene = new Scene(docPatHistPane, 800, 400);
				ProjectMain.getStage().setScene(docPatHistScene);
				ProjectMain.getStage().setTitle("Doctor Home Screen");
			}
			
			else
			{
				PopupMessages.error("Staff Login Invalid", "Invalid Staff Username or Password. Please try again.");
			}
		});
	}
}












import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import java.time.Year;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
public class PatientAccountCreation extends HBox
{
	public Label firstName;
	public Label lastName;
	public Label dateOfBirth;
	public TextField firstNameField;
	public TextField lastNameField;
	public Text message;
	public ComboBox<String> dobDayBox;
	public ComboBox<String> dobMonthBox;
	public ComboBox<String> dobYearBox;
	public Button createAccount;
	public Button backToLogin;

	public PatientAccountCreation(ArrayList<Staff> sList, ArrayList<Patient> pList)
	{
		HBox dobHBox = new HBox();
		GridPane dPane = new GridPane();
		dPane.setVgap(10);
		GridPane mPane = new GridPane();
		mPane.setVgap(10);
		GridPane yPane = new GridPane();
		yPane.setVgap(10);
		HBox buttonBox = new HBox();
		
		firstName = new Label("First Name");
		lastName = new Label("Last Name");
		dateOfBirth = new Label("Date of Birth");
		
		message = new Text("Create a Patient Account");
		message.setFont(Font.font(30));
		
		createAccount = new Button("Create Account");
		backToLogin = new Button("Back to Login");
		
		firstNameField = new TextField();
		lastNameField = new TextField();
		
		dobDayBox = new ComboBox<String>();
		dobMonthBox = new ComboBox<String>();
		dobYearBox = new ComboBox<String>();
		
		dobDayBox.setValue("Select");
		dobMonthBox.setValue("Select");
		dobYearBox.setValue("Select");
		
		dobMonthBox.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12");
		
		for(int i = 1; i <= 31; i++) 
		{
			dobDayBox.getItems().add(String.valueOf(i));
		}
		
		for(int i = Year.now().getValue(); i >= 1900; i--) 
		{
			dobYearBox.getItems().add(String.valueOf(i));
		}
		
		GridPane outerPane = new GridPane();
		outerPane.setAlignment(Pos.CENTER);
		GridPane mainPane = new GridPane();
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setPadding(new Insets(10, 10, 10, 10));
		
		dPane.add(dobDayBox, 0, 1);
		
		mPane.add(dobMonthBox, 0, 1);
		
		yPane.add(dobYearBox, 0, 1);
		
		dobHBox.setSpacing(10);
		dobHBox.getChildren().add(mPane);
		dobHBox.getChildren().add(dPane);
		dobHBox.getChildren().add(yPane);
		
		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
		buttonBox.getChildren().add(createAccount);
		buttonBox.getChildren().add(backToLogin);
		
		mainPane.setMinSize(600, 300);
		mainPane.add(firstName, 0, 0);
		mainPane.add(firstNameField, 0, 1);
		mainPane.add(lastName, 1, 0);
		mainPane.add(lastNameField, 1, 1);
		mainPane.add(dateOfBirth, 2, 0);
		mainPane.add(dobHBox, 2, 1);
		mainPane.add(buttonBox, 2, 4);
		
		mainPane.setHgap(10);
		mainPane.setVgap(15);
		
		BorderPane pane = new BorderPane();
		BorderPane.setAlignment(mainPane, Pos.CENTER);
		pane.setCenter(mainPane);
		pane.setPadding(new Insets(10, 10, 10, 10));
		BorderPane.setAlignment(message, Pos.CENTER);
		pane.setTop(message);
		
		outerPane.add(pane, 0, 0);
		outerPane.setHgap(10);
		outerPane.setVgap(15);
		this.getChildren().add(outerPane);
				
		backToLogin.setOnAction(event -> 
		{
			MainLogin login = new MainLogin();
			StackPane loginPane = new StackPane();
			loginPane.getChildren().add(login);
			Scene loginScene = new Scene(loginPane, 300, 400);
			ProjectMain.getStage().setScene(loginScene);
		});
		
		createAccount.setOnAction(event ->
		{
			try
			{
				Patient newPatient = new Patient();
				newPatient.setPatientName(firstNameField.getText(), lastNameField.getText());
				newPatient.setDateOfBirth(dobDayBox.getValue(), dobMonthBox.getValue(), dobYearBox.getValue());
				int count = 0;
				for(@SuppressWarnings("unused") Patient patient : pList)
				{
					if(count == 0)
					{
						count++;
					}
					else if(count == 1)
					{
						count++;
					}
					else
					{
						count = 0;
					}
				}
				
				pList.add(newPatient);
				if(count == 0)
				{
					newPatient.setDoctorName(sList.get(0).getFirstName(), sList.get(0).getLastName());
				}
				
				else if(count == 1)
				{
					newPatient.setDoctorName(sList.get(0).getFirstName(), sList.get(0).getLastName());
				}
				
				else
				{
					newPatient.setDoctorName(sList.get(0).getFirstName(), sList.get(0).getLastName());
				}
				
				FileWriter writer = new FileWriter("Patients.txt", true);
				writer.write(newPatient.savingPatient(firstNameField.getText(), lastNameField.getText(), dobMonthBox.getValue(), dobDayBox.getValue(), dobYearBox.getValue(), newPatient.getDoctorName()));
				writer.close();
				PopupMessages.error("Patient account successfully created", "The account for " + firstNameField.getText() + " " + lastNameField.getText() + " has been created. Please return to main login and use the recently created account.");
				
				for(Patient p : pList)
				{
					System.out.println(p.toString());
				}
				
			}
			
			catch(IOException e)
			{
				PopupMessages.error("Error", "Patients.txt file does not exist");
			}
		});
	}
}



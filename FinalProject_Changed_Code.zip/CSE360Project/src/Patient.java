public class Patient 
{
	String patientFullName;
	String firstName;
	String lastName;
	String dateOfBirth;
	String dobMonth;
	String dobDay;
	String dobYear;
	String userName;
	String password;
	String doctorName;
	String weight;
	String temp;
	String height;
	String bloodP;
	String concerns;
	
	public Patient()
	{
		patientFullName = "";
		firstName = "";
		lastName = "";
		dateOfBirth = "";
		dobMonth = "";
		dobDay = "";
		dobYear = "";
		userName = "";
		doctorName = "temp";
		weight = "";
		temp = "";
		height = "";
		bloodP = "";
		concerns = "";
	}
	
	Patient(String tempFirst, String tempLast, String tempMonth, String tempDay, String tempYear)
	{
		setPatientName(tempFirst, tempLast);
		setDateOfBirth(tempMonth, tempDay, tempYear);
	}
	
	Patient(String tempFirst, String tempLast, String tempBP, String tempBT)
	{
		setPatientName(tempFirst, tempLast);
		setBloodP(tempBP);
		setTemp(tempBT);
	}
	
	public void readFromFilePatient(String[] data)
	{
		setPatientName(data[0], data[1]);
		setUserName(data[0]);
		setPassword(data[1]);
		
		setDateOfBirth(data[2], data[3], data[4]);
		if(data.length != 7)
		{
			setDoctorName(data[5], data[6]);
			if(data.length == 12)
			{
				setWeight(data[7]);
				setHeight(data[8]);
				setTemp(data[9]);
				setBloodP(data[10]);
			}
		}
		
	}
	
	
	
	
	public String getPatientName()
	{
		return patientFullName;
	}
	
	public String getDateOfBirth()
	{
		return dateOfBirth;
	}
	
	public String getDoctorName()
	{
		return doctorName;
	}
	
	public String getUserName()
	{
		return userName;
	}
	
	public String getPassWord()
	{
		return password;
	}
	
	public String getWeight()
	{
		return weight;
	}
	
	public String getHeight()
	{
		return height;
	}
	
	public String getBloodP()
	{
		return bloodP;
	}
	
	public String getTemp()
	{
		return temp;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	   
	public String getLastName()
	{
		return lastName;
	}
	   
	public String getMonth()
	{
		return dobMonth;
	}
	  
	public String getDay()
	{
		return dobDay;
	}
	   
	public String getYear()
	{
		return dobYear;
	}
	
	public String getConcerns()
	{
		return concerns;
	}
	
	
	
	
	
	public void setUserName(String tempUser)
	{
		userName = tempUser;
	}
	
	public void setPassword(String tempPass)
	{
		password = tempPass;
	}
	
	public void setWeight(String tempWeight)
	{
		weight = tempWeight;
	}
	
	public void setTemp(String tempTemp)
	{
		temp = tempTemp;
	}
	
	public void setHeight(String tempHeight)
	{
		height = tempHeight;
	}
	
	public void setBloodP(String tempBloodP)
	{
		bloodP = tempBloodP;
	}
	
	public void setConcerns(String tempConcerns)
	{
		concerns = tempConcerns;
	}
	
	public String toString()
	{
		String result = "\nFull Name: " + patientFullName + "\nDate of Birth: " + userName + "\nPhone Number: " + doctorName + "\n";
		return result;
	}
	
	public String savingPatient(String tempFirst, String tempLast, String tempMonth, String tempDay, String tempYear, String tempDoctor)
	{
		String saveLine = tempFirst + "," + tempLast + "," + tempMonth + "," + tempDay + "," + tempYear + "," + tempDoctor + "\n";
		return saveLine;
	}
	
	
	public void setPatientName(String tempfirst, String tempLast)
	{
		firstName = tempfirst;
		lastName = tempLast;
		patientFullName = tempfirst + " " + tempLast;
		setUserName(tempfirst);
		setPassword(tempLast);
	}
	
	public void setDateOfBirth(String tempMonth, String tempDay, String tempYear)
	{
		dobMonth = tempMonth;
		dobDay = tempDay;
		dobYear = tempYear;
		dateOfBirth = tempMonth + "/" + tempDay + "/" + tempYear;
	}
	
	public void setDoctorName(String docFirst, String docLast)
	{
		if(doctorName.equals("temp"))
		{
			doctorName = docFirst + "," + docLast;
		}
	}
	
	public String saveLine()
	{
		if(weight.equals(""))
		{
			return firstName + "," + lastName + "," + dobMonth + "," + dobDay + "," + dobYear + "," + doctorName + "\n";
		}
		else
		{
			return firstName + "," + lastName + "," + dobMonth + "," + dobDay + "," + dobYear + "," + doctorName + "," + weight + "," + height + "," + temp + "," + bloodP + "," + concerns + "\n";
		}
	}
}

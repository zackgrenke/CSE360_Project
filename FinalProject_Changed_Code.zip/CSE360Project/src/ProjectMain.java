import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

public class ProjectMain extends Application
{
	private static Stage projectMainScene;
	
	public static Stage getStage()
	{
		return projectMainScene;
	}
	
	public void start(Stage stage)
	{
		MainLogin userLogin = new MainLogin();
		StackPane lPane = new StackPane();
		lPane.getChildren().add(userLogin);
		
		Scene login = new Scene(lPane, 300, 400);
		projectMainScene = stage;
        stage.setTitle("Patient Login");
        stage.setScene(login);
        stage.show();
	}
	
	public static void main(String[]args) 
	{
		launch(args);
	}
}

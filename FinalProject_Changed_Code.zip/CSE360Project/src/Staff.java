public class Staff
{
	String firstName;
	String lastName;
	String fullName;
	String username;
	String password;
	Boolean isDoctor;
	String doctorNumber;
	
	public Staff()
	{
		firstName = "?";
		lastName = "?";
		username = "?";
		password = "?";
		isDoctor = false;
		doctorNumber = "";
	}
	
	Staff(String tempFullName, String tempID)
	{
		setFirstName(tempFullName);
		setLastName(tempFullName);
		setUser(tempID);
	}
	
	public void setIndexes(String[] index)
	{
		setFirstName(index[0]);
		setLastName(index[1]);
		setName(index[0], index[1]);
		setUser(index[2]);
		setPassword(index[3]);
		if(index.length != 4)
		{
			setDoctorNumber(index[4]);
		}

		String doctorCheck = index[2]; 
		if(doctorCheck.charAt(0) == 'D')
		{
			isDoctor = true;
		}
		else
		{
			isDoctor = false;
		}
	}

	public String getFirstName() 
	{
		return firstName;
	}

	public void setFirstName(String tempFirstName) 
	{
		firstName = tempFirstName;
	}
	
	public String getLastName() 
	{
		return lastName;
	}

	public void setLastName(String tempLastName) 
	{
		lastName = tempLastName;
	}
	
	public void setName(String tempFirstName, String tempLastName)
	{
		fullName = tempFirstName + " " + tempLastName;
	}
	public String getName()
	{
		return fullName;
	}
	
	public String getUser()
	{
		return username;
	}
	
	public void setUser(String tempUser)
	{
		username = tempUser;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public void setPassword(String tempPassword)
	{
		password = tempPassword;
	}
	
	public void setIsDoc(Boolean isDoc)
	{
		if(username.charAt(0) == 'D')
		{
			isDoctor = true;
		}
		else
		{
			isDoctor = false;
		}
	}
	
	public boolean getisDoctor()
	{
		return isDoctor;
	}
	
	public String getDoctorNumber()
	{
		return doctorNumber;
	}
	
	public void setDoctorNumber(String tempNumber)
	{
		doctorNumber = tempNumber;
	}
}

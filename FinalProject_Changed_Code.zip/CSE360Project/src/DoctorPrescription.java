import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;

public class DoctorPrescription extends HBox
{
	public Label patientConcerns;
	public Label prescName;
	public TextArea patientConcernsArea;
	public TextField prescNameField;
	public Button toPharmButton;
	public Button logoutButton;
	
	public DoctorPrescription(Patient patient, ArrayList<Patient> pList)
	{
		HBox buttonBox = new HBox();

		patientConcerns = new Label("Patient Health Concerns");
		prescName = new Label("Prescription Name");
		logoutButton = new Button("Logout");
		toPharmButton = new Button("Send To Pharmacy");
		prescNameField = new TextField();
		patientConcernsArea = new TextArea("Enter any concerns that the doctor may have for the patient");
		patientConcernsArea.setEditable(true);
		prescNameField = new TextField();
		
		GridPane outerPane = new GridPane();
		outerPane.setAlignment(Pos.CENTER);
		GridPane mainPane = new GridPane();
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setPadding(new Insets(10, 10, 10, 10));
		mainPane.setMinSize(600, 300);
		
		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
		buttonBox.getChildren().add(logoutButton);
		buttonBox.getChildren().add(toPharmButton);
		
		mainPane.add(patientConcerns, 0, 0);
		GridPane.setHalignment(patientConcerns, HPos.CENTER);
		mainPane.add(patientConcernsArea, 0, 1);
		
		mainPane.add(prescName, 0, 2);
		GridPane.setHalignment(prescName, HPos.CENTER);
		mainPane.add(prescNameField, 0, 3);
		mainPane.add(buttonBox, 0, 4);

		mainPane.setHgap(10);
		mainPane.setVgap(15);
		
		BorderPane pane = new BorderPane();
		BorderPane.setAlignment(mainPane, Pos.CENTER);
		pane.setCenter(mainPane);
		pane.setPadding(new Insets(5, 5, 5, 5));

		outerPane.add(pane, 0, 0);

		outerPane.setHgap(12);
		outerPane.setVgap(12);

		this.getChildren().add(outerPane);
		
		logoutButton.setOnAction(event -> 
		{
			MainLogin login = new MainLogin();
			StackPane loginPane = new StackPane();
			loginPane.getChildren().add(login);
			Scene loginScene = new Scene(loginPane, 300, 400);
			ProjectMain.getStage().setScene(loginScene);
		});
		
		toPharmButton.setOnAction(event ->
		{
			if(prescNameField.getText().isEmpty())
			{
				PopupMessages.error("Error", "Please enter a prescription name");
			}
			else
			{
				try
				{
					FileWriter writer = new FileWriter("Patients.txt", false);
					for(Patient p : pList)
					{
						if(p.getPatientName().equals(patient.getPatientName()))
						{
							
							p.setConcerns(patientConcernsArea.getText());
							writer.write(p.saveLine());
						}
						
						else
						{
							writer.write(p.saveLine());
						}
					}
					writer.close();
				}
				
				catch(IOException except)
				{
					PopupMessages.error("Error", "Missing Patients.txt file");
				}
				PopupMessages.error("Prescription Sent", prescNameField.getText() + " has been sent to the pharmacy for the patient to pick up");
			}
		});
	}
}












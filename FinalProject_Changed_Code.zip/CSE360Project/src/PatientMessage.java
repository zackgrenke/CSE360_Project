import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;

public class PatientMessage extends HBox
{
	public Label patientConcerns;
	public TextArea patientConcernsArea;
	
	public Button sendMessageButton;
	public Button logoutButton;
	public CheckBox isUrgentBox;
	
	public PatientMessage(Patient patient) 
	{
		HBox buttonBox = new HBox();

		patientConcerns = new Label("Send a Message to Your Doctor");
		sendMessageButton = new Button("Send Message");
		logoutButton = new Button("Logout");
		patientConcernsArea = new TextArea("Write message here...");
		patientConcernsArea.setEditable(true);
		isUrgentBox = new CheckBox("Urgent?");
		
		GridPane outerPane = new GridPane();
		outerPane.setAlignment(Pos.CENTER);
		GridPane mainPane = new GridPane();
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setPadding(new Insets(10, 10, 10, 10));

		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
		buttonBox.getChildren().add(isUrgentBox);
		buttonBox.getChildren().add(sendMessageButton);
		buttonBox.getChildren().add(logoutButton);


		mainPane.add(patientConcerns, 0, 0);
		GridPane.setHalignment(patientConcerns, HPos.CENTER);
		mainPane.add(patientConcernsArea, 0, 1);
		mainPane.add(buttonBox, 0, 3);
	
		
		mainPane.setHgap(10);
		mainPane.setVgap(15);
		mainPane.setMinSize(600, 300);
		
		BorderPane pane = new BorderPane();
		BorderPane.setAlignment(mainPane, Pos.CENTER);
		pane.setCenter(mainPane);
		pane.setPadding(new Insets(5, 5, 5, 5));
		
		outerPane.add(pane, 0, 0);
		outerPane.setHgap(12);
		outerPane.setVgap(12);
		this.getChildren().add(outerPane);
		
		logoutButton.setOnAction(event -> 
		{
			MainLogin mainLogin = new MainLogin();
			StackPane loginSPane = new StackPane();
			loginSPane.getChildren().add(mainLogin);
			Scene loginScene = new Scene(loginSPane, 300, 400);
			ProjectMain.getStage().setScene(loginScene);
		});
		
		sendMessageButton.setOnAction(event ->
		{
			if(isUrgentBox.isSelected())
			{
				PopupMessages.error("Urgent Patient Message", "Your urgent message has been forwarded to the help desk. They will see this message immediately and forwarded it to the correct doctor.");
			}
			else
			{
				PopupMessages.error("Patient Message", "Your message has been sent to your doctor. They will reply as soon as they can.");
			}
			
		});
	}
}
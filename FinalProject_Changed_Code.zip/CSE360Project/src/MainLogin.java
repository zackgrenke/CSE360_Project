import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class MainLogin extends HBox
{
	public Label firstNameLabel;
	public Label lastNameLabel;
	public TextField firstNameField;
	public TextField lastNameField;
	public Text pLogin;
	public Button createAccountButton;
	public Button loginButton;
	public Button staffLoginButton;
	public ArrayList<Patient> pList;
	public ArrayList<Staff> sList;
	
	public MainLogin()
	{
		pList = new ArrayList<Patient>();
		sList = new ArrayList<Staff>();

		
		try 
		{
			FileReader fr = new FileReader("Staff.txt");
			BufferedReader br = new BufferedReader(fr);
			
			String line = br.readLine();
			while(line != null)
			{
				String[] attributes = line.split(",");
				Staff newStaff = new Staff();
				newStaff.setIndexes(attributes);
				sList.add(newStaff);
				line = br.readLine();
			}
			br.close();
		} 
		
		catch (IOException ioe) 
		{
			PopupMessages.error("Error", "Please make an account or program is missing the Patients.txt file");
		}
		
		
		try 
		{
			FileReader fr = new FileReader("Patients.txt");
			BufferedReader br = new BufferedReader(fr);
			
			String line = br.readLine();
			
			while(line != null)
			{
				String[] attributes = line.split(",");
				Patient newPatient = new Patient();
				newPatient.readFromFilePatient(attributes);
				pList.add(newPatient);
				line = br.readLine();
			}
			br.close();
		} 
		
		catch (IOException ioe) 
		{
			PopupMessages.error("Error", "Please make an account or program is missing the Patients.txt file");
		}
		
		
		int count = 0;
		for(Patient p : pList)
		{
			
			if(count == 0)
			{
				p.setDoctorName(sList.get(0).getFirstName(), sList.get(0).getLastName());
				count++;
			}
			
			else if(count == 1)
			{
				p.setDoctorName(sList.get(0).getFirstName(), sList.get(0).getLastName());
				count++;
			}
			
			else
			{
				p.setDoctorName(sList.get(0).getFirstName(), sList.get(0).getLastName());
				count = 0;
			}
		}
	
		
		HBox buttonBox = new HBox();
		
		firstNameLabel = new Label("Patient First Name");
		firstNameLabel.setAlignment(Pos.CENTER);
		lastNameLabel = new Label("Patient Last Name");
		lastNameLabel.setAlignment(Pos.CENTER);
		

		pLogin = new Text("Patient Login");
		pLogin.setFont(Font.font(36));
		
		
		createAccountButton = new Button("Create Account");
		loginButton = new Button("Login");
		staffLoginButton = new Button("Staff Login");
		
		firstNameField = new TextField();
		lastNameField = new TextField();
		
		GridPane outerPane = new GridPane();
		outerPane.setAlignment(Pos.CENTER);
		GridPane mainPane = new GridPane();
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setPadding(new Insets(10, 10, 10, 10));
		
		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_CENTER);
		buttonBox.getChildren().add(createAccountButton);
		buttonBox.getChildren().add(loginButton);
		buttonBox.getChildren().add(staffLoginButton);
		
		mainPane.setMinSize(600, 300);
		mainPane.add(firstNameLabel, 0, 1);
		GridPane.setHalignment(firstNameLabel, HPos.CENTER);
		mainPane.add(firstNameField, 0, 2);
		
		mainPane.add(lastNameLabel, 0, 3);
		GridPane.setHalignment(lastNameLabel, HPos.CENTER);
		mainPane.add(lastNameField, 0, 4);
		
		
		mainPane.add(buttonBox, 0, 5);
		
		mainPane.setHgap(10);
		mainPane.setVgap(15);
		
		BorderPane pane = new BorderPane();
		BorderPane.setAlignment(mainPane, Pos.CENTER);
		pane.setCenter(mainPane);
		pane.setPadding(new Insets(5, 5, 5, 5));
		BorderPane.setAlignment(pLogin, Pos.CENTER);
		pane.setTop(pLogin);
		
		outerPane.add(pane, 0, 0);
		
		outerPane.setHgap(12);
		outerPane.setVgap(12);
		
		this.getChildren().add(outerPane);
		
		staffLoginButton.setOnAction(event -> 
		{
			StaffLogin staff = new StaffLogin(pList, sList);
			StackPane staffLoginPane = new StackPane();
			staffLoginPane.getChildren().add(staff);
			Scene staffLoginScene = new Scene(staffLoginPane, 300, 400);
			ProjectMain.getStage().setScene(staffLoginScene);
			ProjectMain.getStage().setTitle("Staff Login");
		});
		
		createAccountButton.setOnAction(event -> 
		{
			PatientAccountCreation newPatient = new PatientAccountCreation(sList, pList);
			StackPane newPatientPane = new StackPane();
			newPatientPane.getChildren().add(newPatient);
			Scene newPatientScene = new Scene(newPatientPane, 600, 350);
			ProjectMain.getStage().setScene(newPatientScene);
			ProjectMain.getStage().setTitle("Create Account");
		});
		
		loginButton.setOnAction(event -> 
		{
			String firstName = firstNameField.getText();
			String lastName = lastNameField.getText();
			Boolean validUser = false;
			Patient currentPatient = null;
			
			for(Patient p : pList)
			{
				if(p.getUserName().equals(firstName) && p.getPassWord().equals(lastName))
				{
					validUser = true;
					currentPatient = p;
					break;
				}
				
				else
				{
					validUser = false;
				}
			}
			
			if(validUser == true)
			{
				PatientMessage patient = new PatientMessage(currentPatient);
				StackPane currentPatientPane = new StackPane();
				currentPatientPane.getChildren().add(patient);
				Scene currentPatientScene = new Scene(currentPatientPane, 600, 400);
				ProjectMain.getStage().setScene(currentPatientScene);
				ProjectMain.getStage().setTitle("Patient Portal");
			}
			
			else
			{
				PopupMessages.error("Login Error", "Login not correct, please check credentials or create a new patient account.");
			}
		});
	}
}















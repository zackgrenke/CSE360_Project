import java.util.ArrayList;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;



public class NursePatientHistory extends HBox
{
	public Label patientName;
	public Label patientConcerns;

	public TextField patientNameField;
	public TextArea patientConcernsArea;
	
	public Button nextButton;
	
	public NursePatientHistory(ArrayList<Patient> pList, Staff user)
	{
		HBox buttonBox = new HBox();

		patientName = new Label("Patient Name");
		patientConcerns = new Label("Patient Allergies/Health Concerns");
		nextButton = new Button("Next");
		patientNameField = new TextField();
		patientConcernsArea = new TextArea("Enter any allergy and/or health concerns here...");
		patientConcernsArea.setEditable(true);
		
		GridPane outerPane = new GridPane();
		outerPane.setAlignment(Pos.CENTER);
		GridPane mainPane = new GridPane();
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setPadding(new Insets(10, 10, 10, 10));

		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
		buttonBox.getChildren().add(nextButton);

		mainPane.add(patientConcerns, 0, 2);
		GridPane.setHalignment(patientConcerns, HPos.CENTER);
		mainPane.add(patientConcernsArea, 0, 3);
		
		
		mainPane.add(patientName, 0, 0);
		GridPane.setHalignment(patientName, HPos.CENTER);
		mainPane.add(patientNameField, 0, 1);
		mainPane.add(buttonBox, 0, 4);
	
		
		mainPane.setHgap(10);
		mainPane.setVgap(15);
		mainPane.setMinSize(600, 300);
		
		BorderPane pane = new BorderPane();
		BorderPane.setAlignment(mainPane, Pos.CENTER);
		pane.setCenter(mainPane);
		pane.setPadding(new Insets(5, 5, 5, 5));
		
		outerPane.add(pane, 0, 0);
		outerPane.setHgap(12);
		outerPane.setVgap(12);
		
		
		this.getChildren().add(outerPane);
		
		nextButton.setOnAction(event -> 
		{
			Patient patient = new Patient();
			if(patientNameField.getText().isEmpty())
			{
				PopupMessages.error("Error", "Please enter a patient name");
			}
			
			else
			{
				for(Patient p : pList)
				{
					if(p.getPatientName().equals(patientNameField.getText()))
					{
						patient = p;
						System.out.println(patient.getFirstName());
						break;
					}
				}
				
				DoctorPrescription doctorPresc = new DoctorPrescription(patient, pList);
				StackPane doctorPrescPane = new StackPane();
				doctorPrescPane.getChildren().add(doctorPresc);
				Scene doctorPrescScene = new Scene(doctorPrescPane, 600, 400);
				ProjectMain.getStage().setScene(doctorPrescScene);
			}
		});
	}
}












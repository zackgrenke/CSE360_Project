// Assignment 6: ASU - CSE 205
// Name:Wilfredo Gumaru II
// StudentID:1214914766
//Lecture Date and Time: Tuesday 4:30
//  Description: GeneratePane creates a pane where a user can enter
//  department information and create a list of available departments.

/* --------------- */
/* Import Packages */
/* --------------- */

import java.util.ArrayList;

import javafx.event.ActionEvent; //**Need to import
import javafx.event.EventHandler; //**Need to import

// JavaFX classes
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 * GeneratePane builds a pane where a user can enter a department
 * information and create a list of available departments.
 */
public class GeneratePane extends HBox {
    /* ------------------ */
    /* Instance variables */
    /* ------------------ */
    private Label blankLabel;
    private TextField deptText;
    private TextField facText;
    private TextField uniText;
    private TextArea textArea;
    ArrayList<Department> departList;
    private SelectPane selectPane; // The relationship between GeneratePane and SelectPane is Aggregation
    //declare and init

    /**
     * CreatePane constructor
     *
     * @param list   the list of departments
     * @param sePane the SelectPane instance
     */
    public GeneratePane(ArrayList<Department> list, SelectPane sePane) {
        /* ------------------------------ */
        /* Instantiate instance variables */
        /* ------------------------------ */
        this.departList = list;
        this.selectPane = sePane;

        //initialize each instance variable (textfields, labels, textarea, button, etc.)
        //and set up the layout
        Button deptButton = new Button("Add a Department");
        deptButton.setOnAction(new ButtonHandler());
        blankLabel = new Label("          ");
        Label deptLabel = new Label("Department Title");
        deptText = new TextField();        //setup as requested
        Label numFaculty = new Label("Number of faculty");
        facText = new TextField();
        Label nameUniversity = new Label("Name of University");
        uniText = new TextField();
        textArea = new TextArea();
        textArea.setText("No department"); //default message
        HBox mainHBox = new HBox(170);
        VBox vBox1 = new VBox();
        VBox vBox2 = new VBox();
        GridPane gridPane = new GridPane(); //gridpane layout
        gridPane.add(blankLabel, 0, 0, 1, 1);
        gridPane.add(deptLabel, 1, 1, 1, 1);
        gridPane.add(numFaculty, 1, 2, 1, 1);
        gridPane.add(nameUniversity, 1, 3, 1, 1);
        gridPane.add(deptText, 4, 1, 1, 1);
        gridPane.add(facText, 4, 2, 1, 1);
        gridPane.add(uniText, 4, 3, 1, 1);
        gridPane.add(deptButton, 4, 4, 1, 1);
        //create a GridPane to hold labels & text fields.
        //you can choose to use .setPadding() or setHgap(), setVgap()
        textArea.setPrefSize(400,400); //formatting shit
        gridPane.setVgap(10);
        //to control the spacing and gap, etc.

        // Set both left and right columns to 50% width (half of window)
        ColumnConstraints halfWidth = new ColumnConstraints();
        halfWidth.setPercentWidth(50);
        gridPane.getColumnConstraints().addAll(halfWidth, halfWidth);
        //You might need to create a sub pane to hold the button

        //Set up the layout for the left half of the GeneratePane.
        vBox1.getChildren().add(gridPane);
        vBox2.getChildren().add(textArea);
        mainHBox.getChildren().addAll(vBox1,vBox2); //adding all into my hbox, somewhat like russian nesting doll
        this.getChildren().add(mainHBox);
        //the right half of the GeneratePane is simply a TextArea object
        //Note: a ScrollPane will be added to it automatically when there are no more space
        //Add the left half and right half to the GeneratePane
        //Note: GeneratePane extends from mainHBox
        //register/link source object with event handler
        // Bind button click action to event handler


    } // end of constructor

    /**
     * ButtonHandler ButtonHandler listens to see if the button "Add a department" is pushed
     * or not, When the event occurs, it get a department's Title, number of faculties,
     * and its university information from the relevant text fields, then create a
     * new department and adds it to the departList. Meanwhile it will display the department's
     * information inside the text area. using the toString method of the Department
     * class. It also does error checking in case any of the text fields are empty,
     * or a non-numeric value was entered for number of faculty
     */
    private class ButtonHandler implements EventHandler<ActionEvent> {
        /**
         * handle Override the abstract method handle()
         */
        public void handle(ActionEvent event) {
            // Declare local variables
            Department newDepart;
            int numberOfFaculty = 0;
            String deptName = deptText.getText();
            String facName = facText.getText();
            String uniName = uniText.getText();
            if ((deptName.length() == 0) || facName.length() == 0 || (uniName.length() == 0)) {
                blankLabel.setText("Please fill all fields"); //making sure it is all filled
                blankLabel.setTextFill(Color.RED);
                // If any field is empty, set isEmptyFields flag to true

                // Display error message if there are empty fields

                // If all fields are filled, try to add the department
            } else {
                try {
                    numberOfFaculty = Integer.valueOf(facName);
                    Boolean deptExists = false;
                    for(int i = 0; i < departList.size();i++) {  //checking if there is a duplicate
                        Department dept = departList.get(i);
                        if (deptName.equals(dept.getDeptName())
                            && (Integer.valueOf(facName) == dept.getNumberOfMembers())
                            && uniName.equals(dept.getUniversity())
                        ) {
                            blankLabel.setText("Department is not added \n - already exists");
                            blankLabel.setTextFill(Color.RED);
                            deptExists = true;
                            break;
                        }
                    }
                    if (deptExists == false) { //if there is no duplicate, then I add
                        newDepart = new Department();
                        newDepart.setDeptName(deptName);
                        newDepart.setNumberOfMembers(numberOfFaculty);
                        newDepart.setUniversity(uniName);
                        blankLabel.setText("Department added");
                        blankLabel.setTextFill(Color.RED);
                        departList.add(newDepart);
                        selectPane.updateDepartList(newDepart);
                        if (textArea.getText().equals( "No department")) { //conditional to put in text box
                            textArea.setText(newDepart.toString());
                        }
                        else {
                            textArea.appendText(newDepart.toString()); //adds on instead of replacing
                        }
                        deptText.clear(); //clears all the fields
                        facText.clear();
                        uniText.clear();
                    }
                    /*
                     * Cast faculties Field to an integer, throws NumberFormatException if unsuccessful
                     */
                    // Data is valid, so create new Department object and populate data

                    // Loop through existing departments to check for duplicates
                    // do not add it to the list if it exists and display a message


                    // department is not a duplicate, so display it and add it to list

                } //end of try
                catch (NumberFormatException e) {
                    // If the number of faculties entered was not an integer, display an error
                    blankLabel.setText("Please enter an integer for \n the number of faculty");
                    blankLabel.setTextFill(Color.RED);
                    return;

                }
                catch (Exception e) {
                    return;
                    // Catches generic exception and displays message
                    // Used to display 'Department is not added - already exist' message if department already exist
                }
            } // end of handle() method
        } // end of ButtonHandler class
    } // end of GeneratePane class
}




